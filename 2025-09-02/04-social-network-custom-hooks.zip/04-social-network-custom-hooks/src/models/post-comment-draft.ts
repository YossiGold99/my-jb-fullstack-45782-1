export default interface PostCommentDraft {
    body: string
}