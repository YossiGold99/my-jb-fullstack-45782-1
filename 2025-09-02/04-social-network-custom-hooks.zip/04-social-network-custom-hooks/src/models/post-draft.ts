export default interface PostDraft {
    title: string,
    body: string,
}