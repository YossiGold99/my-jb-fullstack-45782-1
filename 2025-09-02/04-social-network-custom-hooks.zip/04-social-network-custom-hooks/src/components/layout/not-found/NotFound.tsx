import './NotFound.css'

export default function NotFound() {
    return (
        <div className='NotFound'>
            404 not found, where is your head?
        </div>
    )
}